<?php

if(!defined('INCLUDE_CHECK')) die('You are not allowed to execute this file directly');

// If the poll has been submitted:
if($_POST['sortdata'])
{
	// The data arrives as a comma-separated string,
	// so we extract each post ids:
	$data=explode(',',str_replace('li','',$_POST['sortdata']));

	// Getting the number of objects
	list($tot_objects) = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM sort_objects"));

	if(count($data)!=$tot_objects) die("Wrong data!");

	foreach($data as $k=>$v)
	{
		// Building the sql query:
		$str[]='('.(int)$v.','.($tot_objects-$k).')';
	}
	
	$str = 'VALUES'.join(',',$str);
	
	// This will limit voting to once a day per IP:
	mysql_query("	INSERT INTO `sort_votes` (ip,date_submit,dt_submit)
					VALUES ('".$_SERVER['REMOTE_ADDR']."',NOW(),NOW())");

	//	If the user has not voted before today:
	if(mysql_affected_rows($link)==1)
	{
		mysql_query('	INSERT INTO `sort_objects` (id,votes) '.$str.'
						ON DUPLICATE KEY UPDATE votes = votes+VALUES(votes)');
	}
}

//	Selecting the sample tutorials and ordering 
//	them by the votes each of them received:
$res = mysql_query("SELECT * FROM sort_objects ORDER BY votes DESC");

$maxVote=0;
$bars=array();

while($row=mysql_fetch_assoc($res))
{
	$bars[]=$row;
	
	// Storing the max vote, so we can scale the bars of the chart:
	if($row['votes']>$maxVote) $maxVote = $row['votes'];
}

$barstr='';

// The colors of the bars:
$colors=array('#ff9900','#66cc00','#3399cc','#dd0000','#800080');

foreach($bars as $k=>$v)
{
	// Buildling the bar string:
	$barstr.='
		<div class="bar" style="width:'.max((int)(($v['votes']/$maxVote)*450),100).'px;background:'.$colors[$k].'">
			<a href="'.$v['url'].'" title="'.$v['title'].'">'.$v['short'].'</a>	
		</div>';
}

// The total number of votes cast in the poll:
list($totVotes) = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM sort_votes"));

?>


<div class="chart">

<?php echo $barstr?>

</div>

<a href="demo.php" class="button">Go Back<span></span></a>

<div class="tot-votes"><?php echo $totVotes?> votes</div>