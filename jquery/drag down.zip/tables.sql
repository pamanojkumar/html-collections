﻿--
-- Table structure for table `sort_objects`
--

CREATE TABLE `sort_objects` (
  `id` int(6) NOT NULL auto_increment,
  `title` varchar(128) collate utf8_unicode_ci NOT NULL default '',
  `img` varchar(128) collate utf8_unicode_ci NOT NULL default '',
  `description` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `short` varchar(128) collate utf8_unicode_ci NOT NULL default '',
  `url` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `votes` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `sort_objects`
--

INSERT INTO `sort_objects` VALUES(1, 'A Beautiful Apple-style Slideshow Gallery With CSS & jQuery', 'http://tutorialzine.com/img/posts/483.jpg', 'This week, we are making an Apple-like slideshow gallery, similar to the one they use on their website to showcase their products. It will be entirely front-end based, no PHP or databases required.', 'Apple Slideshow', 'http://tutorialzine.com/2009/11/beautiful-apple-gallery-slideshow/', 12);
INSERT INTO `sort_objects` VALUES(2, 'A Twitter List Powered Fan Page', 'http://tutorialzine.com/img/posts/494.jpg', 'We are using the Twitter API and the newly released lists, to create a fan page widget that allows your visitors to include themselves in a specially crafted fan list in your account.', 'Twitter Fan Page', 'http://tutorialzine.com/2009/11/twitter-list-ajax-fanpage/', 16);
INSERT INTO `sort_objects` VALUES(3, 'An AJAX Based Shopping Cart with PHP, CSS & jQuery', 'http://tutorialzine.com/img/posts/394.jpg', 'In this tutorial we are going to create an AJAX-driven shopping cart. All the products are going to be stored in a MySQL database, with PHP processing the data and jQuery handling the front end.', 'Shopping Cart', 'http://tutorialzine.com/2009/09/shopping-cart-php-jquery/', 17);
INSERT INTO `sort_objects` VALUES(4, 'Making A Cool Login System With PHP, MySQL & jQuery', 'http://tutorialzine.com/img/posts/450.jpg', 'Today we are making a cool & simple login / registration system. It will give you the ability to easily create a member-only area on your site and provide an easy registration process.', 'Login System', 'http://tutorialzine.com/2009/10/cool-login-system-php-jquery/', 7);
INSERT INTO `sort_objects` VALUES(5, 'Making a Google Wave History Slider', 'http://tutorialzine.com/img/posts/472.jpg', 'Using PHP and jQuery we are going to create a Google Wave-like history slider. Using it, we will enable our visitors to go back and forth in time to view the changes that take place on a comment thread.', 'Google Slider', 'http://tutorialzine.com/2009/10/google-wave-history-slider-jquery/', 8);

-- --------------------------------------------------------

--
-- Table structure for table `sort_votes`
--

CREATE TABLE `sort_votes` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(15) collate utf8_unicode_ci NOT NULL default '',
  `date_submit` date NOT NULL default '0000-00-00',
  `dt_submit` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `ip` (`ip`,`date_submit`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
